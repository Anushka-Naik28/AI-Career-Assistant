'use server';
/**
 * @fileOverview A Genkit flow to compare a job description against a resume.
 *
 * - matchJobDescription - A function that handles the job description and resume matching process.
 * - MatchJobDescriptionInput - The input type for the matchJobDescription function.
 * - MatchJobDescriptionOutput - The return type for the matchJobDescription function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const MatchJobDescriptionInputSchema = z.object({
  jobDescription: z.string().describe('The full text of the job description.'),
  resumeDataUri:
    z.string().describe(
      "A resume in PDF format, as a data URI that must include a MIME type and use Base64 encoding. Expected format: 'data:<mimetype>;base64,<encoded_data>'."
    ),
});
export type MatchJobDescriptionInput = z.infer<typeof MatchJobDescriptionInputSchema>;

const MatchJobDescriptionOutputSchema = z.object({
  matchPercentage: z
    .number()
    .min(0)
    .max(100)
    .describe('A percentage score indicating how well the resume matches the job description.'),
  skillGaps: z
    .array(z.string())
    .describe('A list of specific skills mentioned in the job description that are missing from the resume.'),
  improvementSuggestions: z
    .string()
    .describe(
      'Detailed suggestions on how to improve the resume to better match the specific job description, focusing on incorporating keywords and relevant experiences.'
    ),
});
export type MatchJobDescriptionOutput = z.infer<typeof MatchJobDescriptionOutputSchema>;

export async function matchJobDescription(
  input: MatchJobDescriptionInput
): Promise<MatchJobDescriptionOutput> {
  return matchJobDescriptionFlow(input);
}

const prompt = ai.definePrompt({
  name: 'matchJobDescriptionPrompt',
  input: {schema: MatchJobDescriptionInputSchema},
  output: {schema: MatchJobDescriptionOutputSchema},
  prompt: `You are an expert career advisor specializing in resume analysis and job matching. Your task is to compare a candidate's resume with a given job description.

First, analyze the provided job description and identify key requirements, skills, and responsibilities.
Next, review the resume and assess how well it aligns with these requirements.

Based on your analysis, provide the following:
1.  A match percentage (0-100) indicating the overall fit.
2.  A list of specific skill gaps, highlighting important skills from the job description that are not evident in the resume.
3.  Detailed and actionable suggestions on how the candidate can improve their resume to better match this particular job role, including specific keywords or experiences to add or emphasize.

Job Description:
{{{jobDescription}}}

Resume: {{media url=resumeDataUri}}`,
});

const matchJobDescriptionFlow = ai.defineFlow(
  {
    name: 'matchJobDescriptionFlow',
    inputSchema: MatchJobDescriptionInputSchema,
    outputSchema: MatchJobDescriptionOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    if (!output) {
      throw new Error('Failed to generate match analysis.');
    }
    return output;
  }
);
