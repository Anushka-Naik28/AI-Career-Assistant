# **App Name**: CareerCopilot AI

## Core Features:

- Intelligent Resume Audit: Upload PDF resumes to extract skills and experience using a parser tool to generate real-time ATS scoring and keyword gap analysis.
- Precision Job Matcher: A comparison engine that uses AI to analyze job descriptions against candidate profiles, highlighting specific skill mismatches.
- Adaptive Career Roadmaps: Generates a dynamic learning path based on target roles like Frontend or AI Engineer, tracking milestone completion in the database.
- AI Mock Interviewer: An interactive tool that simulates behavioral and technical interviews with personalized scoring and real-time improvement suggestions.
- Smart Project Curator: Recommends categorized projects (Beginner to Advanced) based on identified skill gaps and specific professional goals.
- SaaS Branding Suite: Automatically generates optimized LinkedIn summaries, headlines, and professional bios based on analyzed experience data.
- Career Readiness Analytics: Visual dashboard tracking skill growth trends, interview readiness scores, and overall project completion status.

## Style Guidelines:

- Primary color: Vibrant Electric Violet (#7C3AED), reflecting innovation and technical authority.
- Background color: Deep Charcoal-Midnight (#0B0A0F), providing a sleek, premium dark-mode foundation.
- Accent color: Sophisticated Sky Blue (#60A5FA), creating sharp contrast for high-priority calls to action and icons.
- Font pairing: 'Space Grotesk' for modern, tech-focused headlines and 'Inter' for highly legible dashboard body text.
- Bento-grid style dashboard layout inspired by high-end design systems like Linear and Stripe, featuring glassmorphism cards.
- Smooth, fluid state transitions using micro-interactions for a 'living interface' feel during AI processing states.
- Minimalist, thin-stroke monochrome icons to maintain a sophisticated, clean SaaS aesthetic.