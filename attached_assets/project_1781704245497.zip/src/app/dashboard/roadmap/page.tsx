
"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { generateCareerRoadmap, type GenerateCareerRoadmapOutput } from "@/ai/flows/generate-career-roadmap";
import { Loader2, MapPin, Calendar, BookOpen, GraduationCap, Code } from "lucide-react";

const roles = [
  'Frontend Developer',
  'Full Stack Developer',
  'AI Engineer',
  'Data Analyst',
  'Blockchain Developer',
];

export default function RoadmapGenerator() {
  const [loading, setLoading] = useState(false);
  const [role, setRole] = useState<string>("");
  const [result, setResult] = useState<GenerateCareerRoadmapOutput | null>(null);

  const handleGenerate = async () => {
    if (!role) return;
    setLoading(true);
    try {
      const roadmap = await generateCareerRoadmap({ targetRole: role as any });
      setResult(roadmap);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-headline font-bold text-gradient mb-2">Adaptive Career Roadmaps</h1>
          <p className="text-muted-foreground">Dynamic learning paths tailored to your dream career.</p>
        </div>
        <div className="flex items-center gap-3">
          <Select value={role} onValueChange={setRole}>
            <SelectTrigger className="w-[240px] glass">
              <SelectValue placeholder="Select Target Role" />
            </SelectTrigger>
            <SelectContent className="glass">
              {roles.map(r => <SelectItem key={r} value={r}>{r}</SelectItem>)}
            </SelectContent>
          </Select>
          <Button onClick={handleGenerate} disabled={loading || !role} className="rounded-full px-8">
            {loading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <BookOpen className="w-4 h-4 mr-2" />}
            Generate
          </Button>
        </div>
      </div>

      {!result ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1,2,3].map(i => (
            <Card key={i} className="glass-card opacity-50 border-dashed border-2">
              <CardContent className="pt-10 pb-10 flex flex-col items-center justify-center text-center">
                <div className="w-12 h-12 rounded-full bg-secondary flex items-center justify-center mb-4" />
                <div className="h-4 w-32 bg-secondary rounded mb-2" />
                <div className="h-3 w-48 bg-secondary rounded" />
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="space-y-12">
          <Card className="glass-card border-primary/20 bg-primary/5">
            <CardContent className="pt-6">
              <h2 className="text-2xl font-headline font-bold mb-4">Journey Overview: {result.roadmap.targetRole}</h2>
              <p className="text-lg leading-relaxed">{result.roadmap.overview}</p>
              <div className="mt-6 flex items-center gap-2 text-primary">
                <Calendar className="w-5 h-5" />
                <span className="font-medium">{result.roadmap.timelineSummary}</span>
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-12">
              <div>
                <h3 className="text-xl font-headline font-bold mb-6 flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-white text-sm">1</div>
                  Strategic Milestones
                </h3>
                <div className="relative pl-8 border-l border-white/10 space-y-10">
                  {result.roadmap.milestones.map((m, i) => (
                    <div key={i} className="relative">
                      <div className="absolute -left-[41px] top-1 w-4 h-4 rounded-full bg-primary ring-4 ring-background shadow-lg shadow-primary/20" />
                      <div className="glass-card p-6 rounded-2xl border-white/10">
                        <div className="flex justify-between items-start mb-2">
                          <h4 className="text-lg font-bold">{m.name}</h4>
                          <span className="text-xs bg-primary/10 text-primary px-3 py-1 rounded-full">{m.durationWeeks} Weeks</span>
                        </div>
                        <p className="text-muted-foreground text-sm">{m.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <h3 className="text-xl font-headline font-bold mb-6 flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-accent flex items-center justify-center text-accent-foreground text-sm">2</div>
                  Recommended Projects
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {result.roadmap.projects.map((p, i) => (
                    <Card key={i} className="glass-card">
                      <CardHeader>
                        <div className="flex justify-between items-center mb-1">
                          <Badge variant="secondary" className="bg-primary/10 text-primary border-primary/20">{p.difficulty}</Badge>
                          <div className="flex gap-1">
                            {p.techStack.slice(0,2).map(t => <Badge key={t} variant="outline" className="text-[10px] px-1.5 py-0">{t}</Badge>)}
                          </div>
                        </div>
                        <CardTitle className="text-lg">{p.name}</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-xs text-muted-foreground line-clamp-2 mb-4">{p.description}</p>
                        <div className="space-y-1">
                          <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-bold">Outcomes</p>
                          <ul className="text-xs space-y-1">
                            {p.learningOutcomes.slice(0,2).map((o, idx) => <li key={idx} className="flex items-center gap-2"><Code className="w-3 h-3 text-primary" />{o}</li>)}
                          </ul>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            </div>

            <div className="space-y-8">
              <Card className="glass-card">
                <CardHeader>
                  <CardTitle className="font-headline text-lg">Key Skills to Master</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {result.roadmap.skills.map((s, i) => (
                      <Badge key={i} variant="outline" className="px-3 py-1 glass">{s}</Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card className="glass-card">
                <CardHeader>
                  <CardTitle className="font-headline text-lg">Top Certifications</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {result.roadmap.certifications.map((c, i) => (
                    <div key={i} className="p-4 rounded-xl bg-white/5 border border-white/5 space-y-2">
                      <div className="flex items-center gap-2 text-primary">
                        <GraduationCap className="w-4 h-4" />
                        <span className="font-bold text-sm">{c.name}</span>
                      </div>
                      <p className="text-xs text-muted-foreground italic">{c.provider}</p>
                      <p className="text-xs text-muted-foreground line-clamp-2">{c.description}</p>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
