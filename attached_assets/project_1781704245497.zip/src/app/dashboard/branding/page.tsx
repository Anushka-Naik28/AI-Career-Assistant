
"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { generateProfessionalContent, type GenerateProfessionalContentOutput } from "@/ai/flows/generate-professional-content-flow";
import { Loader2, Briefcase, Linkedin, UserCircle, Copy, Check } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function BrandingSuite() {
  const [loading, setLoading] = useState(false);
  const [targetRole, setTargetRole] = useState("");
  const [userProfile, setUserProfile] = useState("");
  const [result, setResult] = useState<GenerateProfessionalContentOutput | null>(null);
  const [copied, setCopied] = useState<string | null>(null);
  const { toast } = useToast();

  const handleGenerate = async () => {
    if (!targetRole || !userProfile) {
      toast({ title: "Please fill in all fields", variant: "destructive" });
      return;
    }
    setLoading(true);
    try {
      const mockResumeDataUri = "data:application/pdf;base64,JVBERi0xLjQKJ...";
      const content = await generateProfessionalContent({
        targetRole,
        userProfile,
        resumeDataUri: mockResumeDataUri
      });
      setResult(content);
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopied(id);
    setTimeout(() => setCopied(null), 2000);
    toast({ title: "Copied to clipboard" });
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-headline font-bold text-gradient mb-2">SaaS Branding Suite</h1>
        <p className="text-muted-foreground">AI-optimized professional profiles for LinkedIn and Portfolios.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <Card className="glass-card lg:col-span-1 h-fit">
          <CardHeader>
            <CardTitle className="font-headline">Branding Inputs</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <label className="text-sm font-medium text-muted-foreground">Target Role</label>
              <Input 
                placeholder="e.g. Senior Frontend Engineer" 
                className="glass"
                value={targetRole}
                onChange={(e) => setTargetRole(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-muted-foreground">Core Skills & Goals</label>
              <Textarea 
                placeholder="Tell us about your achievements and career aspirations..." 
                className="glass min-h-[150px] resize-none"
                value={userProfile}
                onChange={(e) => setUserProfile(e.target.value)}
              />
            </div>
            <Button className="w-full rounded-full h-12" onClick={handleGenerate} disabled={loading}>
              {loading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Briefcase className="w-4 h-4 mr-2" />}
              Generate Branding
            </Button>
          </CardContent>
        </Card>

        <div className="lg:col-span-2">
          {!result ? (
            <div className="h-full min-h-[500px] glass-card border-dashed flex flex-col items-center justify-center p-12 text-center">
              <SparklesIcon className="w-16 h-16 text-primary/20 mb-4" />
              <h3 className="text-xl font-headline font-bold text-muted-foreground">Your brand kit will appear here</h3>
              <p className="text-muted-foreground max-w-sm mx-auto mt-2">
                We'll generate a headline, summary, bio and project descriptions tailored to your target role.
              </p>
            </div>
          ) : (
            <Tabs defaultValue="linkedin" className="space-y-6">
              <TabsList className="glass p-1 h-12 rounded-xl grid grid-cols-3">
                <TabsTrigger value="linkedin" className="rounded-lg data-[state=active]:bg-primary data-[state=active]:text-white">
                  <Linkedin className="w-4 h-4 mr-2" /> LinkedIn
                </TabsTrigger>
                <TabsTrigger value="bio" className="rounded-lg data-[state=active]:bg-primary data-[state=active]:text-white">
                  <UserCircle className="w-4 h-4 mr-2" /> Prof. Bio
                </TabsTrigger>
                <TabsTrigger value="projects" className="rounded-lg data-[state=active]:bg-primary data-[state=active]:text-white">
                  <Briefcase className="w-4 h-4 mr-2" /> Projects
                </TabsTrigger>
              </TabsList>

              <TabsContent value="linkedin" className="space-y-6 animate-fade-in-up">
                <Card className="glass-card">
                  <CardHeader className="flex flex-row items-center justify-between">
                    <CardTitle className="text-lg">LinkedIn Headline</CardTitle>
                    <Button variant="ghost" size="icon" onClick={() => copyToClipboard(result.linkedInHeadline, 'headline')}>
                      {copied === 'headline' ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
                    </Button>
                  </CardHeader>
                  <CardContent>
                    <p className="text-xl font-headline font-bold text-primary">{result.linkedInHeadline}</p>
                  </CardContent>
                </Card>
                <Card className="glass-card">
                  <CardHeader className="flex flex-row items-center justify-between">
                    <CardTitle className="text-lg">LinkedIn Summary</CardTitle>
                    <Button variant="ghost" size="icon" onClick={() => copyToClipboard(result.linkedInSummary, 'summary')}>
                      {copied === 'summary' ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
                    </Button>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm leading-relaxed whitespace-pre-wrap">{result.linkedInSummary}</p>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="bio" className="animate-fade-in-up">
                <Card className="glass-card">
                  <CardHeader className="flex flex-row items-center justify-between">
                    <CardTitle className="text-lg">Professional Bio</CardTitle>
                    <Button variant="ghost" size="icon" onClick={() => copyToClipboard(result.professionalBio, 'bio')}>
                      {copied === 'bio' ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
                    </Button>
                  </CardHeader>
                  <CardContent>
                    <p className="text-lg leading-relaxed">{result.professionalBio}</p>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="projects" className="space-y-4 animate-fade-in-up">
                {result.projectDescriptions.map((proj, i) => (
                  <Card key={i} className="glass-card">
                    <CardHeader className="flex flex-row items-center justify-between py-4">
                      <CardTitle className="text-md">Project Impact {i + 1}</CardTitle>
                      <Button variant="ghost" size="icon" onClick={() => copyToClipboard(proj, `proj-${i}`)}>
                        {copied === `proj-${i}` ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
                      </Button>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm leading-relaxed text-muted-foreground">{proj}</p>
                    </CardContent>
                  </Card>
                ))}
              </TabsContent>
            </Tabs>
          )}
        </div>
      </div>
    </div>
  );
}

function SparklesIcon(props: any) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z" />
      <path d="M5 3v4" />
      <path d="M19 17v4" />
      <path d="M3 5h4" />
      <path d="M17 19h4" />
    </svg>
  );
}
