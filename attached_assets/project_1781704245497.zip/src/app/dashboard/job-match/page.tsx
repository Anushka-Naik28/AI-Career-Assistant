
"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, Target, CheckCircle2, ChevronRight, XCircle } from "lucide-react";
import { matchJobDescription, type MatchJobDescriptionOutput } from "@/ai/flows/match-job-description";
import { useToast } from "@/hooks/use-toast";

export default function JobMatcher() {
  const [loading, setLoading] = useState(false);
  const [jobDescription, setJobDescription] = useState("");
  const [result, setResult] = useState<MatchJobDescriptionOutput | null>(null);
  const { toast } = useToast();

  const handleMatch = async () => {
    if (!jobDescription) {
      toast({ title: "Please enter a job description", variant: "destructive" });
      return;
    }

    setLoading(true);
    try {
      // For MVP we mock a resume data uri since we don't store it yet
      // In a real app, this would come from user profile / database
      const mockResumeDataUri = "data:application/pdf;base64,JVBERi0xLjQKJ...";
      const match = await matchJobDescription({ jobDescription, resumeDataUri: mockResumeDataUri });
      setResult(match);
    } catch (error) {
      toast({ title: "Matching failed", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-headline font-bold text-gradient mb-2">Precision Job Matcher</h1>
        <p className="text-muted-foreground">Compare your resume against a specific job role to identify gaps.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <Card className="glass-card flex flex-col h-full">
          <CardHeader>
            <CardTitle className="font-headline">Job Description</CardTitle>
          </CardHeader>
          <CardContent className="flex-1 flex flex-col gap-4">
            <Textarea
              placeholder="Paste the full job description here..."
              className="flex-1 min-h-[400px] bg-white/5 border-white/10 resize-none p-6"
              value={jobDescription}
              onChange={(e) => setJobDescription(e.target.value)}
            />
            <Button size="lg" className="w-full h-12 rounded-full" onClick={handleMatch} disabled={loading}>
              {loading ? <Loader2 className="w-5 h-5 animate-spin mr-2" /> : <Target className="w-5 h-5 mr-2" />}
              {loading ? "Matching..." : "Analyze Match"}
            </Button>
          </CardContent>
        </Card>

        <div className="space-y-6">
          {!result ? (
            <Card className="glass-card h-full border-dashed flex items-center justify-center p-12 text-center">
              <div>
                <Target className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-20" />
                <h3 className="text-xl font-headline font-bold text-muted-foreground">Results will appear here</h3>
                <p className="text-muted-foreground max-w-xs mx-auto mt-2">
                  Paste a job description and click analyze to see how well you match the role.
                </p>
              </div>
            </Card>
          ) : (
            <>
              <Card className="glass-card overflow-hidden">
                <div className="h-2 bg-primary" style={{ width: `${result.matchPercentage}%` }} />
                <CardHeader>
                  <CardTitle className="flex justify-between items-center">
                    Match Percentage
                    <span className="text-3xl font-bold text-primary">{result.matchPercentage}%</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="w-full bg-secondary h-4 rounded-full">
                    <div className="bg-primary h-4 rounded-full transition-all duration-1000" style={{ width: `${result.matchPercentage}%` }} />
                  </div>
                </CardContent>
              </Card>

              <Card className="glass-card">
                <CardHeader>
                  <CardTitle className="font-headline text-destructive flex items-center gap-2">
                    <XCircle className="w-5 h-5" />
                    Missing Skills
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3">
                    {result.skillGaps.map((skill, i) => (
                      <li key={i} className="flex items-center gap-3 text-sm p-3 rounded-lg bg-destructive/10 border border-destructive/20">
                        <ChevronRight className="w-4 h-4 text-destructive" />
                        {skill}
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>

              <Card className="glass-card">
                <CardHeader>
                  <CardTitle className="font-headline flex items-center gap-2">
                    <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                    Recommendations
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm leading-relaxed whitespace-pre-wrap">{result.improvementSuggestions}</p>
                </CardContent>
              </Card>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
