
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Zap, Rocket, Shield, Star, CheckCircle2, ArrowRight } from "lucide-react";
import Image from "next/image";

export default function LandingPage() {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="fixed top-0 w-full z-50 glass border-b border-white/10">
        <div className="container mx-auto px-6 h-20 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Zap className="w-6 h-6 text-primary fill-primary" />
            <span className="text-2xl font-headline font-bold tracking-tight">CareerCopilot AI</span>
          </div>
          <nav className="hidden md:flex items-center gap-8">
            <Link href="#features" className="text-sm font-medium hover:text-primary transition-colors">Features</Link>
            <Link href="#about" className="text-sm font-medium hover:text-primary transition-colors">How it works</Link>
            <Link href="#pricing" className="text-sm font-medium hover:text-primary transition-colors">Pricing</Link>
          </nav>
          <div className="flex items-center gap-4">
            <Button variant="ghost" className="hidden md:flex">Sign In</Button>
            <Button asChild className="rounded-full px-8 bg-primary hover:bg-primary/90 shadow-lg shadow-primary/20">
              <Link href="/dashboard">Get Started</Link>
            </Button>
          </div>
        </div>
      </header>

      <main className="flex-1 pt-32">
        {/* Hero Section */}
        <section className="container mx-auto px-6 text-center relative">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 -z-10 w-full max-w-4xl h-96 bg-primary/20 blur-[120px] rounded-full" />
          <h1 className="text-5xl md:text-7xl font-headline font-bold leading-tight mb-6">
            Land your <span className="text-gradient">Dream Role</span> <br />with AI Intelligence
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-10">
            The all-in-one AI career development platform for students and job seekers. 
            Resume auditing, mock interviews, and personalized roadmaps.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Button size="lg" className="rounded-full px-10 bg-primary hover:bg-primary/90 h-14 text-lg">
              Start Free Trial <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
            <Button size="lg" variant="outline" className="rounded-full px-10 h-14 text-lg glass">
              Watch Demo
            </Button>
          </div>

          <div className="mt-20 relative max-w-5xl mx-auto p-4 glass rounded-2xl border-white/20 shadow-2xl animate-fade-in-up">
            <div className="relative aspect-video rounded-xl overflow-hidden border border-white/10">
              <Image 
                src="https://picsum.photos/seed/copilot-hero/1200/800" 
                alt="Dashboard Preview" 
                fill 
                className="object-cover"
                data-ai-hint="software dashboard"
              />
            </div>
          </div>
        </section>

        {/* Stats */}
        <section className="py-20 bg-white/5 mt-20">
          <div className="container mx-auto px-6 grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-4xl font-headline font-bold text-primary mb-2">50k+</div>
              <div className="text-muted-foreground uppercase text-sm tracking-widest">Resumes Audited</div>
            </div>
            <div>
              <div className="text-4xl font-headline font-bold text-primary mb-2">12k</div>
              <div className="text-muted-foreground uppercase text-sm tracking-widest">Successful Hires</div>
            </div>
            <div>
              <div className="text-4xl font-headline font-bold text-primary mb-2">94%</div>
              <div className="text-muted-foreground uppercase text-sm tracking-widest">Score Improvement</div>
            </div>
            <div>
              <div className="text-4xl font-headline font-bold text-primary mb-2">10+</div>
              <div className="text-muted-foreground uppercase text-sm tracking-widest">Target Roles</div>
            </div>
          </div>
        </section>

        {/* Features */}
        <section id="features" className="py-32 container mx-auto px-6">
          <div className="text-center mb-20">
            <h2 className="text-4xl font-headline font-bold mb-4">Everything you need to <span className="text-primary">Win</span></h2>
            <p className="text-muted-foreground">Cutting edge AI tools designed for modern job markets.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="p-8 glass-card rounded-2xl group hover:-translate-y-2 transition-transform">
              <div className="w-12 h-12 rounded-xl bg-primary/20 flex items-center justify-center mb-6 text-primary group-hover:scale-110 transition-transform">
                <Rocket className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-headline font-bold mb-3">Resume Audit</h3>
              <p className="text-muted-foreground">Instant ATS scoring and keyword analysis to bypass robot filters with ease.</p>
            </div>
            <div className="p-8 glass-card rounded-2xl group hover:-translate-y-2 transition-transform">
              <div className="w-12 h-12 rounded-xl bg-accent/20 flex items-center justify-center mb-6 text-accent group-hover:scale-110 transition-transform">
                <Shield className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-headline font-bold mb-3">Mock Interviews</h3>
              <p className="text-muted-foreground">Real-time feedback on technical and behavioral answers using advanced LLMs.</p>
            </div>
            <div className="p-8 glass-card rounded-2xl group hover:-translate-y-2 transition-transform">
              <div className="w-12 h-12 rounded-xl bg-primary/20 flex items-center justify-center mb-6 text-primary group-hover:scale-110 transition-transform">
                <Star className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-headline font-bold mb-3">Career Roadmaps</h3>
              <p className="text-muted-foreground">Personalized learning paths for high-growth tech roles like AI Engineer.</p>
            </div>
          </div>
        </section>
      </main>

      <footer className="py-20 border-t border-white/10 bg-black/50 backdrop-blur-md">
        <div className="container mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="flex items-center gap-2">
            <Zap className="w-5 h-5 text-primary fill-primary" />
            <span className="text-xl font-headline font-bold">CareerCopilot AI</span>
          </div>
          <p className="text-sm text-muted-foreground">© 2024 Copilot Labs. All rights reserved.</p>
          <div className="flex gap-6">
            <Link href="#" className="text-muted-foreground hover:text-white transition-colors">Twitter</Link>
            <Link href="#" className="text-muted-foreground hover:text-white transition-colors">LinkedIn</Link>
            <Link href="#" className="text-muted-foreground hover:text-white transition-colors">GitHub</Link>
          </div>
        </div>
      </footer>
    </div>
  );
}
