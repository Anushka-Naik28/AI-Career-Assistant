
"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { FileUp, Loader2, CheckCircle2, AlertCircle, Sparkles } from "lucide-react";
import { analyzeResume, type AnalyzeResumeOutput } from "@/ai/flows/analyze-resume-flow";
import { useToast } from "@/hooks/use-toast";

export default function ResumeAnalyzer() {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<AnalyzeResumeOutput | null>(null);
  const { toast } = useToast();

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.type !== "application/pdf") {
      toast({
        variant: "destructive",
        title: "Invalid file type",
        description: "Please upload a PDF document.",
      });
      return;
    }

    setLoading(true);
    try {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = async () => {
        const dataUri = reader.result as string;
        const analysis = await analyzeResume({ resumePdfDataUri: dataUri });
        setResult(analysis);
        setLoading(false);
      };
    } catch (error) {
      console.error(error);
      toast({
        variant: "destructive",
        title: "Analysis failed",
        description: "There was an error processing your resume. Please try again.",
      });
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-headline font-bold text-gradient mb-2">Intelligent Resume Audit</h1>
        <p className="text-muted-foreground">Upload your resume to get real-time ATS scoring and optimization tips.</p>
      </div>

      {!result ? (
        <Card className="glass-card border-dashed border-2 py-20 flex flex-col items-center justify-center text-center">
          <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mb-6">
            {loading ? <Loader2 className="w-8 h-8 text-primary animate-spin" /> : <FileUp className="w-8 h-8 text-primary" />}
          </div>
          <h2 className="text-xl font-headline font-bold mb-2">
            {loading ? "Analyzing your profile..." : "Drop your resume here"}
          </h2>
          <p className="text-muted-foreground mb-8 max-w-xs">Supported format: PDF. Max size: 5MB.</p>
          <div className="relative">
            <input
              type="file"
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
              onChange={handleFileUpload}
              disabled={loading}
              accept=".pdf"
            />
            <Button disabled={loading} size="lg" className="rounded-full px-8">
              {loading ? "Processing..." : "Select File"}
            </Button>
          </div>
        </Card>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <Card className="glass-card lg:col-span-1">
            <CardHeader>
              <CardTitle className="font-headline">Overall Fit</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="relative w-48 h-48 mx-auto">
                <svg className="w-full h-full" viewBox="0 0 100 100">
                  <circle className="text-secondary stroke-current" strokeWidth="8" fill="transparent" r="40" cx="50" cy="50" />
                  <circle 
                    className="text-primary stroke-current" 
                    strokeWidth="8" 
                    strokeDasharray={`${result.atsScore * 2.51} 251`} 
                    strokeLinecap="round" 
                    fill="transparent" 
                    r="40" cx="50" cy="50" 
                    transform="rotate(-90 50 50)"
                  />
                  <text x="50" y="50" textAnchor="middle" dy="7" className="text-2xl font-bold fill-current font-headline">
                    {result.atsScore}%
                  </text>
                </svg>
              </div>
              <div className="text-center">
                <h3 className="text-lg font-bold mb-1">ATS Compatibility Score</h3>
                <p className="text-sm text-muted-foreground">
                  Your resume is highly optimized for current industry standards.
                </p>
              </div>
              <Button variant="outline" className="w-full glass" onClick={() => setResult(null)}>
                Upload New Resume
              </Button>
            </CardContent>
          </Card>

          <div className="lg:col-span-2 space-y-8">
            <Card className="glass-card">
              <CardHeader className="flex flex-row items-center gap-2">
                <AlertCircle className="w-5 h-5 text-accent" />
                <CardTitle className="font-headline">Keyword Gaps</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {result.keywordGaps.map((gap, i) => (
                    <Badge key={i} variant="secondary" className="px-3 py-1 bg-accent/10 text-accent border-accent/20">
                      {gap}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card className="glass-card">
              <CardHeader className="flex flex-row items-center gap-2">
                <Sparkles className="w-5 h-5 text-primary" />
                <CardTitle className="font-headline">Improvement Suggestions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {result.improvementSuggestions.map((suggestion, i) => (
                  <div key={i} className="flex gap-4 p-4 rounded-xl bg-white/5 border border-white/5">
                    <CheckCircle2 className="w-5 h-5 text-primary shrink-0 mt-0.5" />
                    <p className="text-sm">{suggestion}</p>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card className="glass-card">
              <CardHeader>
                <CardTitle className="font-headline">Extracted Skills</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {result.extractedInfo.skills.map((skill, i) => (
                    <Badge key={i} variant="outline" className="px-3 py-1 glass">
                      {skill}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      )}
    </div>
  );
}
