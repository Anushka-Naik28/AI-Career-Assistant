import { config } from 'dotenv';
config();

import '@/ai/flows/match-job-description.ts';
import '@/ai/flows/generate-professional-content-flow.ts';
import '@/ai/flows/analyze-resume-flow.ts';
import '@/ai/flows/generate-career-roadmap.ts';
import '@/ai/flows/conduct-mock-interview.ts';