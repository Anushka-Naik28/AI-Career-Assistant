
"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { conductMockInterview, type ConductMockInterviewOutput } from "@/ai/flows/conduct-mock-interview";
import { Loader2, Mic, Send, MessageSquare, History, Trophy, Sparkles } from "lucide-react";

export default function MockInterview() {
  const [session, setSession] = useState<ConductMockInterviewOutput | null>(null);
  const [loading, setLoading] = useState(false);
  const [answer, setAnswer] = useState("");
  const [history, setHistory] = useState<{ q: string; a: string; feedback?: string; score?: number }[]>([]);
  const [questionCount, setQuestionCount] = useState(1);

  const startInterview = async () => {
    setLoading(true);
    try {
      const first = await conductMockInterview({
        role: "Software Engineer",
        experienceLevel: "Mid-level",
        currentQuestionNumber: 1
      });
      setSession(first);
    } finally {
      setLoading(false);
    }
  };

  const handleNext = async () => {
    if (!answer || !session) return;
    setLoading(true);
    try {
      const next = await conductMockInterview({
        role: "Software Engineer",
        experienceLevel: "Mid-level",
        currentQuestionNumber: questionCount + 1,
        previousQuestion: session.nextQuestion,
        userAnswer: answer
      });
      
      setHistory(prev => [...prev, { 
        q: session.nextQuestion, 
        a: answer, 
        feedback: next.feedback,
        score: next.score
      }]);
      
      setSession(next);
      setAnswer("");
      setQuestionCount(prev => prev + 1);
    } finally {
      setLoading(false);
    }
  };

  if (!session) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] text-center space-y-8 animate-fade-in-up">
        <div className="w-20 h-20 rounded-3xl bg-primary/20 flex items-center justify-center text-primary shadow-2xl shadow-primary/20">
          <MessageSquare className="w-10 h-10" />
        </div>
        <div className="max-w-md">
          <h1 className="text-4xl font-headline font-bold mb-4">Master Your Interviews</h1>
          <p className="text-muted-foreground text-lg mb-8">
            Interactive AI-powered mock interviews with real-time feedback and technical evaluation.
          </p>
          <div className="flex flex-wrap justify-center gap-4 mb-8">
            <Badge variant="outline" className="glass py-2 px-4">Technical Proficiency</Badge>
            <Badge variant="outline" className="glass py-2 px-4">Behavioral Analysis</Badge>
            <Badge variant="outline" className="glass py-2 px-4">Detailed Scoring</Badge>
          </div>
          <Button size="lg" className="rounded-full px-12 h-14 text-lg bg-primary hover:bg-primary/90" onClick={startInterview}>
            Start Mock Interview
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      <div className="lg:col-span-2 space-y-6">
        {session.isInterviewComplete ? (
          <Card className="glass-card border-primary bg-primary/5 text-center py-12">
            <CardHeader>
              <Trophy className="w-16 h-16 text-primary mx-auto mb-4" />
              <CardTitle className="text-3xl font-headline">Interview Complete!</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-xl max-w-lg mx-auto">{session.concludingRemarks}</p>
              <div className="pt-8">
                <Button size="lg" className="rounded-full px-8" onClick={() => { setSession(null); setHistory([]); setQuestionCount(1); }}>
                  Back to Dashboard
                </Button>
              </div>
            </CardContent>
          </Card>
        ) : (
          <Card className="glass-card border-white/10 flex flex-col min-h-[500px]">
            <CardHeader className="border-b border-white/5 pb-6">
              <div className="flex justify-between items-center mb-4">
                <Badge className="bg-primary/20 text-primary border-primary/20">Question {questionCount} of 5</Badge>
                <div className="flex items-center gap-2 text-muted-foreground text-sm">
                  <Mic className="w-4 h-4" />
                  Voice mode coming soon
                </div>
              </div>
              <CardTitle className="text-2xl font-headline leading-relaxed">
                {session.nextQuestion}
              </CardTitle>
            </CardHeader>
            <CardContent className="flex-1 pt-6">
              <Textarea
                placeholder="Type your response here..."
                className="w-full h-full min-h-[250px] bg-white/5 border-white/10 resize-none p-6 text-lg focus-visible:ring-primary"
                value={answer}
                onChange={(e) => setAnswer(e.target.value)}
              />
            </CardContent>
            <CardFooter className="border-t border-white/5 pt-6">
              <Button size="lg" className="w-full h-14 rounded-full text-lg shadow-lg shadow-primary/20" disabled={loading || !answer} onClick={handleNext}>
                {loading ? <Loader2 className="w-6 h-6 animate-spin mr-2" /> : <Send className="w-5 h-5 mr-2" />}
                {loading ? "Analyzing..." : "Submit Answer"}
              </Button>
            </CardFooter>
          </Card>
        )}
      </div>

      <div className="space-y-6">
        <Card className="glass-card h-full">
          <CardHeader className="border-b border-white/5">
            <CardTitle className="font-headline flex items-center gap-2">
              <History className="w-5 h-5 text-accent" />
              Interview Progress
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-6 space-y-6">
            {history.length === 0 ? (
              <div className="text-center py-10 opacity-30">
                <Sparkles className="w-10 h-10 mx-auto mb-2" />
                <p className="text-sm">Feedback will appear after your first answer</p>
              </div>
            ) : (
              history.map((h, i) => (
                <div key={i} className="space-y-3 p-4 rounded-2xl bg-white/5 border border-white/5">
                  <div className="flex justify-between items-center">
                    <span className="text-xs font-bold text-muted-foreground uppercase tracking-widest">Q{i+1} Review</span>
                    <Badge className="bg-emerald-500/10 text-emerald-500 border-emerald-500/20">{h.score}% Match</Badge>
                  </div>
                  <p className="text-sm italic text-muted-foreground line-clamp-2">"{h.a}"</p>
                  <p className="text-xs leading-relaxed text-foreground/80">{h.feedback}</p>
                </div>
              ))
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
