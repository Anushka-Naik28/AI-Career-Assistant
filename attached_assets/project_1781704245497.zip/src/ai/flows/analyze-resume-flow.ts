'use server';
/**
 * @fileOverview An AI agent for analyzing resumes. It extracts key information, generates an ATS score,
 * identifies keyword gaps, and provides suggestions for improvement.
 *
 * - analyzeResume - A function that handles the resume analysis process.
 * - AnalyzeResumeInput - The input type for the analyzeResume function.
 * - AnalyzeResumeOutput - The return type for the analyzeResume function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const AnalyzeResumeInputSchema = z.object({
  resumePdfDataUri: z
    .string()
    .describe(
      "The resume PDF content, as a data URI that must include a MIME type and use Base64 encoding. Expected format: 'data:<mimetype>;base64,<encoded_data>'."
    ),
});
export type AnalyzeResumeInput = z.infer<typeof AnalyzeResumeInputSchema>;

const AnalyzeResumeOutputSchema = z.object({
  atsScore: z
    .number()
    .min(0)
    .max(100)
    .describe('An Applicant Tracking System (ATS) compatibility score (0-100).'),
  extractedInfo: z.object({
    skills: z.array(z.string()).describe('A list of key skills extracted from the resume.'),
    education: z
      .array(z.string())
      .describe('A list of educational background entries extracted from the resume.'),
    experience: z
      .array(z.string())
      .describe('A list of work experience entries extracted from the resume.'),
    projects: z
      .array(z.string())
      .describe('A list of projects mentioned in the resume.'),
    certifications: z
      .array(z.string())
      .describe('A list of certifications obtained.'),
  }),
  keywordGaps: z
    .array(z.string())
    .describe(
      'A list of important industry-standard keywords that are missing from the resume but would improve its visibility.'
    ),
  improvementSuggestions: z
    .array(z.string())
    .describe('A list of specific, actionable suggestions to improve the resume.'),
});
export type AnalyzeResumeOutput = z.infer<typeof AnalyzeResumeOutputSchema>;

export async function analyzeResume(input: AnalyzeResumeInput): Promise<AnalyzeResumeOutput> {
  return analyzeResumeFlow(input);
}

const analyzeResumePrompt = ai.definePrompt({
  name: 'analyzeResumePrompt',
  input: { schema: AnalyzeResumeInputSchema },
  output: { schema: AnalyzeResumeOutputSchema },
  prompt: `You are an expert Applicant Tracking System (ATS) resume analyzer. Your goal is to help job seekers optimize their resumes.

Analyze the provided resume PDF and perform the following tasks:
1. Extract key information including skills, education, experience, projects, and certifications.
2. Generate an ATS compatibility score between 0 and 100, where a higher score indicates better compatibility.
3. Identify important industry-standard keywords that are missing from the resume and would improve its ATS visibility.
4. Provide specific, actionable suggestions for improving the resume's content, formatting, and keyword optimization.

Resume: {{media url=resumePdfDataUri}}

Provide the output in a structured JSON format as described by the output schema.`,
});

const analyzeResumeFlow = ai.defineFlow(
  {
    name: 'analyzeResumeFlow',
    inputSchema: AnalyzeResumeInputSchema,
    outputSchema: AnalyzeResumeOutputSchema,
  },
  async (input) => {
    const { output } = await analyzeResumePrompt(input);
    if (!output) {
      throw new Error('Failed to analyze resume.');
    }
    return output;
  }
);
