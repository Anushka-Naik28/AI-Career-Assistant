'use server';
/**
 * @fileOverview A Genkit flow for generating professional branding content such as LinkedIn summaries, headlines, professional bios, and project descriptions.
 *
 * - generateProfessionalContent - A function that handles the content generation process.
 * - GenerateProfessionalContentInput - The input type for the generateProfessionalContent function.
 * - GenerateProfessionalContentOutput - The return type for the generateProfessionalContent function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const GenerateProfessionalContentInputSchema = z.object({
  resumeDataUri:
    z.string()
      .describe(
        "A resume PDF, as a data URI that must include a MIME type and use Base64 encoding. Expected format: 'data:<mimetype>;base64,<encoded_data>'."
      ),
  userProfile: z.string().describe("User's career goals, current role, key skills, and experience details."),
  targetRole: z.string().describe("The specific role the user is targeting (e.g., 'Frontend Developer', 'AI Engineer')."),
  existingContent: z.string().optional().describe("Any existing branding content (e.g., old LinkedIn summary) to consider or build upon."),
});
export type GenerateProfessionalContentInput = z.infer<typeof GenerateProfessionalContentInputSchema>;

const GenerateProfessionalContentOutputSchema = z.object({
  linkedInSummary: z.string().describe("A professional and compelling LinkedIn summary tailored to the target role."),
  linkedInHeadline: z.string().describe("A concise, keyword-rich LinkedIn headline."),
  professionalBio: z.string().describe("A short, impactful professional biography suitable for various platforms."),
  projectDescriptions: z.array(z.string()).describe("An array of detailed project descriptions highlighting achievements, technologies, and impact, based on the resume and user profile."),
});
export type GenerateProfessionalContentOutput = z.infer<typeof GenerateProfessionalContentOutputSchema>;

export async function generateProfessionalContent(input: GenerateProfessionalContentInput): Promise<GenerateProfessionalContentOutput> {
  return generateProfessionalContentFlow(input);
}

const prompt = ai.definePrompt({
  name: 'generateProfessionalContentPrompt',
  input: {schema: GenerateProfessionalContentInputSchema},
  output: {schema: GenerateProfessionalContentOutputSchema},
  prompt: `You are an expert career branding specialist. Your task is to generate professional branding content based on the provided user profile, target role, and resume. Focus on creating a cohesive and impactful online presence.

User Profile: {{{userProfile}}}
Target Role: {{{targetRole}}}

{{#if existingContent}}
Existing Content to consider: {{{existingContent}}}
{{/if}}

Resume: {{media url=resumeDataUri}}

Generate the following content in JSON format, adhering strictly to the provided output schema:
1.  **LinkedIn Summary**: A compelling summary highlighting skills, experience, and career aspirations relevant to the target role.
2.  **LinkedIn Headline**: A concise, keyword-rich headline suitable for LinkedIn.
3.  **Professional Bio**: A brief professional biography for various platforms.
4.  **Project Descriptions**: Detailed descriptions for key projects mentioned in the resume or implied by the profile, focusing on achievements, technologies used, and impact, tailored for a portfolio. If no projects are explicitly mentioned, infer from skills and target role.

Ensure the tone is professional, confident, and aligned with the target role.`,
});

const generateProfessionalContentFlow = ai.defineFlow(
  {
    name: 'generateProfessionalContentFlow',
    inputSchema: GenerateProfessionalContentInputSchema,
    outputSchema: GenerateProfessionalContentOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    if (!output) {
      throw new Error('Failed to generate professional content.');
    }
    return output;
  }
);
