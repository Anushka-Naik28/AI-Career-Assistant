'use server';
/**
 * @fileOverview A Genkit flow for conducting AI-powered mock interviews.
 *
 * - conductMockInterview - A function that handles the mock interview process, generating questions and evaluating answers.
 * - ConductMockInterviewInput - The input type for the conductMockInterview function.
 * - ConductMockInterviewOutput - The return type for the conductMockInterview function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const ConductMockInterviewInputSchema = z.object({
  role: z.string().describe('The target job role for the interview (e.g., "Frontend Developer", "AI Engineer").'),
  experienceLevel: z.string().describe('The candidate\'s experience level (e.g., "Junior", "Mid-level", "Senior").'),
  currentQuestionNumber: z.number().int().min(1).describe('The current question number in the interview sequence.'),
  previousQuestion: z.string().optional().describe('The question previously asked to the user.'),
  userAnswer: z.string().optional().describe('The user\'s answer to the previous question.'),
});
export type ConductMockInterviewInput = z.infer<typeof ConductMockInterviewInputSchema>;

const ConductMockInterviewOutputSchema = z.object({
  nextQuestion: z.string().describe('The next interview question to ask the user. This can be empty if the interview is complete.'),
  feedback: z.string().optional().describe('Detailed feedback on the user\'s previous answer.'),
  score: z.number().int().min(0).max(100).optional().describe('A score (0-100) for the user\'s previous answer.'),
  improvementSuggestions: z.array(z.string()).optional().describe('Actionable suggestions to improve the user\'s previous answer.'),
  isInterviewComplete: z.boolean().describe('Indicates whether the interview has concluded.'),
  concludingRemarks: z.string().optional().describe('Concluding remarks provided if the interview is complete.'),
});
export type ConductMockInterviewOutput = z.infer<typeof ConductMockInterviewOutputSchema>;

export async function conductMockInterview(input: ConductMockInterviewInput): Promise<ConductMockInterviewOutput> {
  return conductMockInterviewFlow(input);
}

const conductMockInterviewPrompt = ai.definePrompt({
  name: 'conductMockInterviewPrompt',
  input: { schema: ConductMockInterviewInputSchema },
  output: { schema: ConductMockInterviewOutputSchema },
  prompt: `You are an AI interviewer for a {{experienceLevel}} {{role}} position.\nYour goal is to simulate a realistic job interview by asking relevant technical and behavioral questions, evaluating the candidate\'s answers, and providing constructive feedback, a score, and suggestions for improvement.\n\nThe interview process should cover a mix of technical and behavioral questions.\nAim for a total of 5-7 meaningful questions.\n\n{{#if userAnswer}}\n  The user just answered the question \"{{{previousQuestion}}}\" with:\n  \"{{{userAnswer}}}\"\n\n  First, provide detailed feedback on this answer, assign a score out of 100 (e.g., if the answer was excellent, give 90-100; if it was poor, give 0-40, etc.), and suggest 2-3 actionable improvements for that answer.\n  Then, based on the current interview progress ({{currentQuestionNumber}} questions asked), decide if the interview should conclude.\n  If {{currentQuestionNumber}} is 5 or more and the conversation feels complete, set \"isInterviewComplete\" to true and provide concise concluding remarks, summarizing the performance and thanking the candidate. Do NOT ask a new question in this case.\n  Otherwise, ask the next interview question, ensuring a good mix of technical and behavioral questions throughout the interview.\n{{else}}\n  This is the start of the interview. Ask the first interview question for a {{experienceLevel}} {{role}} role.\n  Do NOT provide feedback, score, or improvement suggestions for this first turn as there\'s no previous answer.\n  Set \"isInterviewComplete\" to false.\n{{/if}}\n\nEnsure your response is always a valid JSON object matching the defined output schema.\n`,
});

const conductMockInterviewFlow = ai.defineFlow(
  {
    name: 'conductMockInterviewFlow',
    inputSchema: ConductMockInterviewInputSchema,
    outputSchema: ConductMockInterviewOutputSchema,
  },
  async (input) => {
    const { output } = await conductMockInterviewPrompt(input);
    if (!output) {
      throw new Error('Failed to get output from mock interview prompt.');
    }
    return output;
  }
);
