'use server';
/**
 * @fileOverview A Genkit flow for generating personalized career roadmaps based on a target role.
 *
 * - generateCareerRoadmap - A function that handles the career roadmap generation process.
 * - GenerateCareerRoadmapInput - The input type for the generateCareerRoadmap function.
 * - GenerateCareerRoadmapOutput - The return type for the generateCareerRoadmap function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const TargetRoleEnum = z.enum([
  'Frontend Developer',
  'Full Stack Developer',
  'AI Engineer',
  'Data Analyst',
  'Blockchain Developer',
]);

const GenerateCareerRoadmapInputSchema = z.object({
  targetRole: TargetRoleEnum.describe('The target job role for which to generate a career roadmap.'),
});
export type GenerateCareerRoadmapInput = z.infer<typeof GenerateCareerRoadmapInputSchema>;

const GenerateCareerRoadmapOutputSchema = z.object({
  roadmap: z.object({
    targetRole: z.string().describe('The target job role for this roadmap.'),
    overview: z.string().describe('A brief overview of the career roadmap.'),
    skills: z.array(z.string()).describe('A list of essential skills to acquire for this role.'),
    certifications: z.array(
      z.object({
        name: z.string().describe('Name of the certification.'),
        provider: z.string().describe('Provider of the certification (e.g., Coursera, Udemy, AWS, Google Cloud).'),
        description: z.string().describe('Brief description of the certification content and its relevance.'),
      })
    ).describe('Recommended certifications to validate skills.'),
    projects: z.array(
      z.object({
        name: z.string().describe('Name of the project.'),
        description: z.string().describe('Detailed description of the project goals and scope.'),
        difficulty: z.enum(['Beginner', 'Intermediate', 'Advanced']).describe('Difficulty level of the project.'),
        techStack: z.array(z.string()).describe('Key technologies and tools to be used in the project (e.g., Python, TensorFlow, React, Solidity).'),
        learningOutcomes: z.array(z.string()).describe('Specific skills and knowledge gained by completing this project.'),
      })
    ).describe('Recommended projects to build practical experience and a portfolio.'),
    milestones: z.array(
      z.object({
        name: z.string().describe('Name of the milestone (e.g., "Foundational Skills Acquisition", "Portfolio Project Completion").'),
        description: z.string().describe('Description of what needs to be achieved to reach this milestone.'),
        durationWeeks: z.number().describe('Estimated duration in weeks to reach this milestone.'),
      })
    ).describe('Key milestones in the learning journey with estimated durations.'),
    timelineSummary: z.string().describe('A summary of the estimated overall timeline for the entire roadmap and general progression path.'),
  }).describe('The personalized learning roadmap.'),
});
export type GenerateCareerRoadmapOutput = z.infer<typeof GenerateCareerRoadmapOutputSchema>;

export async function generateCareerRoadmap(input: GenerateCareerRoadmapInput): Promise<GenerateCareerRoadmapOutput> {
  return generateCareerRoadmapFlow(input);
}

const generateCareerRoadmapPrompt = ai.definePrompt({
  name: 'generateCareerRoadmapPrompt',
  input: { schema: GenerateCareerRoadmapInputSchema },
  output: { schema: GenerateCareerRoadmapOutputSchema },
  prompt: `You are an expert career counselor specializing in creating detailed and personalized learning roadmaps for aspiring professionals in the tech industry. Your goal is to help a user systematically advance their career by providing a comprehensive plan.

Generate a personalized learning roadmap for the target role: "{{{targetRole}}}".

The roadmap should include:
1.  An 'overview' explaining the roadmap's purpose and what it entails.
2.  A list of 'skills' that are essential for this role.
3.  'certifications' with their names, providers, and descriptions.
4.  'projects' with their names, detailed descriptions, difficulty (Beginner, Intermediate, Advanced), tech stack, and learning outcomes.
5.  'milestones' with names, descriptions, and estimated 'durationWeeks'.
6.  A 'timelineSummary' describing the estimated total duration and progression.

Ensure the output is structured exactly according to the provided JSON schema. Provide realistic, actionable, and up-to-date recommendations. Focus on practical skills and widely recognized certifications and projects relevant to the current job market for the selected role.`,
});

const generateCareerRoadmapFlow = ai.defineFlow(
  {
    name: 'generateCareerRoadmapFlow',
    inputSchema: GenerateCareerRoadmapInputSchema,
    outputSchema: GenerateCareerRoadmapOutputSchema,
  },
  async (input) => {
    const { output } = await generateCareerRoadmapPrompt(input);
    return output!;
  }
);
